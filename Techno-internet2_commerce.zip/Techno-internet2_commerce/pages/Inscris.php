<?php
$ins = new ClientBD($cnx);
$inscrit = $ins->addClient();
?>