<?php
$login = new ClientBD($cnx);
$conn = $login->Connexion();
?>

<h3 class="titreProduits">Connectez-vous</h3>

<div class="container login_form">
    <form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
        <div class="mb-3">
            <label for="exampleInputLogin1" class="form-label">Votre prénom</label>
            <input name="prenom_client" type="text" class="form-control" id="exampleInputLogin1" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Mot de passe</label>
            <input name="password" type="password" class="form-control" id="exampleInputPassword1" required>
        </div>
        <button name="submit_client" type="submit" class="btn btn-outline-primary">Connexion</button>
        <button type="reset" class="btn btn-outline-secondary">Annuler</button>
        <button style="float: right" type="button" class="btn btn-outline-info">
            <a href="index_.php?page=Inscription.php" style="text-decoration: none; color: black;">Inscription</a>
        </button>
    </form>
</div>