<div class="container">
    <div class="titre">À propos de nous</div>
    <section id="intro" class="fadeIn">
        <p id="suite_intro"></p>
        <div class="titre2">Une plateforme pour la mode</div>
        <section id="intro" class="fadeIn">
            <p id="suite_para">
                Palace est une entreprise de mode et de technologie qui continue de se développer en tant que plateforme
                de mode afin de connecter les personnes et la mode en ligne et hors ligne. <br>
                Nous créons des idées et développons des solutions qui permettent à tous les participants
                de générer de la valeur ajoutée par le biais de notre plateforme.
            </p>
        </section>

        <div class="titre2">Expérience d'achat</div>
        <section id="para" class="fadeIn">
            <p id="suite_para">
                Au cœur de notre pensée et de nos actions se trouvent nos clients.
                Nous leur proposons un service exceptionnel et une expérience d'achat unique que nous améliorons sans
                cesse.
            </p>
        </section>

        <div class="titre2">Une technologie d'avant-garde</div>
        <section id="para" class="fadeIn">
            <p id="suite_para">
                La technologie Palace constitue le noyau de tous les produits et services que nous proposons sur notre
                plateforme,
                ainsi que la base de presque tous nos processus internes.
                Notre mission à long terme est d'anticiper les innombrables et divers points d’interaction
                entre les consommateurs et la mode, en vue de concevoir la technologie adaptée pour les réaliser.
            </p>
        </section>

        <div class="titre2">Notre ADN</div>
        <section id="para" class="fadeIn">
            <p id="suite_para">
                Palace sait tirer profit des compétences de ses quatre divisions : Mode, Technologie, Opérations
                commerciales et Logistique.
                Mis à part notre vision d’offrir une valeur ajoutée à tous les participants de l’industrie de la mode,
                la particularité de notre entreprise est de créer un environnement de travail aussi inspirant que
                diversifié
                et
                d’offrir des opportunités illimitées.
            </p>
        </section>
    </section>

</div>