<h3 class="titreProduits">Créer votre compte</h3>
<div class="container login_form">
    <form method="post" action="index_.php?page=Inscris.php">
        <div class="mb-3">
            <label for="nom_client" class="form-label">Nom: </label>
            <input name="nom_client" type="text" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="prenom_client" class="form-label">Prénom: </label>
            <input name="prenom_client" type="text" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="adresse" class="form-label">Adresse: </label>
            <input name="adresse" type="text" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="code_postal" class="form-label">Code postal: </label>
            <input name="code_postal" type="text" class="form-control"  required>
        </div>
        <div class="mb-3">
            <label for="ville" class="form-label">Ville: </label>
            <input name="ville" type="text" class="form-control"  required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">E-mail: </label>
            <input name="email" type="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Mot de passe: </label>
            <input name="password" type="password" class="form-control" required>
        </div>

        <button name="submit_client" type="submit" class="btn btn-outline-primary">S'inscrire</button>
        <button type="reset" class="btn btn-outline-secondary">Annuler</button>
        <button style="float: right" type="button" class="btn btn-outline-info">
            <a href="./index_.php?page=Accueil.php" style="text-decoration: none; color: black;">Accueil</a>
        </button>
    </form>
</div>
