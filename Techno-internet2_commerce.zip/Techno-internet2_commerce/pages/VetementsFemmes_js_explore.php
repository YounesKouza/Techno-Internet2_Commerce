<?php
//var_dump($_GET);
$categ = new ProduitsFemmesBD($cnx);
$produits = $categ->getAllProduitsFemmes();
$nbr_vetF = count($produits);
//var_dump($produits);
?>

<div class="titreProduits">Produits Femmes</div>

<div class="rechercheProduits">
    <form class="search-container">
        <input class="search-data" type="search" placeholder="Rechercher" id="search_Vetement" onkeyup="searchVet()"
               required>
        <button class="fas fa-search" type="submit"></button>
    </form>
</div>

<div class="produits" id="prod">
    <div class="container">
        <div class="row row-cols-1 row-cols- row-cols-sm-3 row-cols-md-3 g-3">
            <?php
            for ($i = 0; $i < $nbr_vetF; $i++) {
                ?>
                <div>
                    <div class="card shadow-sm">
                        <svg class="bd-placeholder-img card-img-top" width="100%" height="250"
                             xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice"
                             focusable="false">

                            <img src="./admin/imagesFemmes/<?php print $produits[$i]->image_produitf; ?>"
                                 style="margin-top: -250px;"/>

                        </svg>

                        <div class="card-body">
                            <p class="card-text_produits">
                                <?php print $produits[$i]->nom_produitf; ?>
                            </p>
                            <p class="card-text_produits">
                                <?php print $produits[$i]->prixunitaire_produitf; ?> €
                            </p>

                            <form method="post" action="./index_.php?page=Panier.php">
                                <input type="hidden" name="id_produit"
                                       value="<?php print $produits[$i]->id_produitf; ?>">
                                <input type="hidden" name="id_produit"
                                       value="<?php print $produits[$i]->prixunitaire_produitf; ?>">

                                <button type="submit" class="btn btn-success">
                                    Ajout <i class="fa fa-shopping-bag"></i>
                                </button>

                            </form>
                        </div>

                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>

