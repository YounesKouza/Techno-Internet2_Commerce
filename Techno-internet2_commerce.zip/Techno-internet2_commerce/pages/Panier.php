<div id="erreur">

    <h1 id="erreur">
        Erreur d'ajout!
    </h1>
    <p id="erreur">Vous devez vous <a href="index_.php?page=login.php">connecter</a> pour ajouter un article au panier
        <br>Ou si vous n'êtes pas membre, cliquez sur <a href="index_.php?page=Inscription.php">ce lien</a>
    </p>

</div>