<?php
$categorie = new CategorieBD($cnx);
$cat = $categorie->getAllCategorie();
$nbr_categorie = count($cat);
?>

<div id="demo" class="carousel slide" data-bs-ride="carousel">

    <div class="carousel-indicators">
        <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    </div>

    <div class="carousel-inner">

        <div class="carousel-item active">
            <a type="button" href="index_.php?page=VetementsHommes_js_explore.php">
                <img class="categorieImage" src="./admin/imagesCategorie/Homme.jpg" style="height: 100%; width: 100%;">
                <div class="carousel-caption">
                    <h3 class="titreProduits2">Produits hommes</h3>
                    <p>Cliquez pour voir les produits concernant les hommes.</p>
                </div>
            </a>
        </div>
        <div class="carousel-item">
            <a type="button" href="index_.php?page=VetementsFemmes_js_explore.php">
                <img class="categorieImage" src="./admin/imagesCategorie/Femme.webp" style="height: 120%; width: 145.5%;">
                <div class="carousel-caption">
                    <h3 class="titreProduits2">Produits femmes</h3>
                    <p>Cliquez pour voir les produits concernant les femmes.</p>
                </div>
            </a>
        </div>

    </div>



    <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>

</div>

<!--
<div class="album py-5 bg-light">
    <div class="container">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-5 g-5">

            <?php
            for ($i = 0; $i < $nbr_categorie; $i++) {
                ?>

                <div class="col">
                    <div class="card shadow-sm">
                        <div class="imagesCategorie">
                            <?php
                            if ($i == 0) {
                                ?>
                                <img class="categorieImage" src="./admin/imagesCategorie/Homme.jpg">
                                <?php
                            } else {
                                ?>
                                <img class="categorieImage" src="./admin/imagesCategorie/Femme.jpg">
                                <?php
                            }
                            ?>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php print $cat[$i]->nom_categorie; ?>
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <?php
                                    if ($i == 0) {
                                        ?>
                                        <a type="button" class="btn btn-sm btn-outline-secondary"
                                           href="index_.php?page=VetementsHommes_js_explore.php">Voir</a>
                                        <?php
                                    } else {
                                        ?>
                                        <a type="button" class="btn btn-sm btn-outline-secondary"
                                           href="index_.php?page=VetementsFemmes_js_explore.php">Voir</a>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <?php
            }
            ?>

        </div>
    </div>
</div>
-->