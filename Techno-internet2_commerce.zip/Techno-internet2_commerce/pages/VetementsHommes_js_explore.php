<?php
//var_dump($_GET);
$categ = new ProduitsHommesBD($cnx);
$produits = $categ->getAllProduitsHommes();
$nbr_vetH = count($produits);
//var_dump($produits);

?>

<div class="titreProduits">Produits Hommes</div>

<div class="rechercheProduits">
    <form class="search-container">
        <input class="search-data" type="search" placeholder="Rechercher" id="search_Vetement" onkeyup="searchVet()"
               required>
        <button class="fas fa-search" type="submit"></button>
    </form>
</div>

<div class="produits" id="prod">
    <div class="container">
        <div class="row row-cols-1 row-cols- row-cols-sm-3 row-cols-md-3 g-3">
            <?php
            for ($i = 0; $i < $nbr_vetH; $i++) {
                ?>
                <div>
                    <div class="card shadow-sm">
                        <svg class="bd-placeholder-img card-img-top" width="100%" height="250"
                             xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice"
                             focusable="false">

                            <img src="./admin/imagesHommes/<?php print $produits[$i]->image_produith; ?>"
                                 style="margin-top: -250px;"/>

                        </svg>

                        <div class="card-body">
                            <p class="card-text_produits">
                                <?php print $produits[$i]->nom_produith; ?>
                            </p>
                            <p class="card-text_produits">
                                <?php print $produits[$i]->prixunitaire_produith; ?> €
                            </p>
                            <form method="post" action="./index_.php?page=Panier.php">
                                <input type="hidden" name="id_produit"
                                       value="<?php print $produits[$i]->id_produith; ?>">
                                <input type="hidden" name="id_produit"
                                       value="<?php print $produits[$i]->prixunitaire_produith; ?>">

                                <button type="submit" class="btn btn-success">
                                    Ajout <i class="fa fa-shopping-bag"></i>
                                </button>

                            </form>

                        </div>

                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>