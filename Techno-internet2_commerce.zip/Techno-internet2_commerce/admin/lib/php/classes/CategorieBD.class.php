<?php

class CategorieBD extends Categorie {
    private $_db;
    private $_array = array();

    function __construct($cnx) {
        $this->_db = $cnx;
    }

    function getAllCategorie(){
        try {
            $query = "select * from categorie order by id_categorie";
            $_resultset = $this->_db->prepare($query);
            $_resultset->execute();

            while($data = $_resultset->fetch()){
                $_array[] = new Categorie($data);
            }
            if(!empty($_array)){
                return $_array;
            }
            else {
                return null;
            }
        }catch(PDOException $e){
            print "Erreur : ".$e->getMessage();
        }
    }

}
