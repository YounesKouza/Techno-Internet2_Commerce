<?php

class ProduitsFemmes {

    private $_attributs = array();

    public function __construct(array $data) { //$data est 1 enregistrement de la BD, reçu de Exemple_classe_metierBD (1 à la fois)
        $this->hydrate($data);
    }

    public function hydrate(array $data){
        foreach($data as $nom_produitf => $nouveau){ //chaque champ est créé et associé à sa valeur
            $this->$nom_produitf = $nouveau;
        }
    }

    public function __get($nom_produitf){ //champ = clé
        if(isset($this->_attributs[$nom_produitf])){
            return $this->_attributs[$nom_produitf];
        }
    }

    public function __set($nom_produitf, $nouveau) {
        $this->_attributs[$nom_produitf]  = $nouveau;
    }


}