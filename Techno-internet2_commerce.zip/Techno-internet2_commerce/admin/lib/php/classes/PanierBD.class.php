<?php

class PanierBD extends Panier
{
    private $_db;
    private $_array = array();

    function __construct($cnx)
    {
        $this->_db = $cnx;
    }

    function getAllPaniers()
    {
        try {
            $query = "select * from panier left join produitsfemmes on panier.id_produitf = produitsfemmes.id_produitf left join produitshommes on panier.id_produith = produitshommes.id_produith order by id_panier";
            $_resultset = $this->_db->prepare($query);
            $_resultset->execute();

            while ($data = $_resultset->fetch()) {
                $_array[] = new Panier($data);
            }
            if (!empty($_array)) {
                return $_array;
            } else {
                return null;
            }
        } catch (PDOException $e) {
            print "Erreur : " . $e->getMessage();
        }
    }

    function addProduct($id_produith, $id_produitf, $id_client, $qte_produit, $prixU, $prixTotal)
    {
        try {
            $this->_db->beginTransaction();
            $query = "insert into panier (id_client, id_produitf, id_produith, prix_unitaire, qte_produit, prixtotal_produit) 
                        values (:id_client, :id_produitf, :id_produith, :prix_unitaire, :qte_produit, :prixtotal_produit)";

            $prixTotal = $prixU * $qte_produit;
            $allTotal = 0.0;
            $allTotal += $prixTotal;

            $_resultset = $this->_db->prepare($query);
            $_resultset->bindValue(':id_client', $id_client);
            $_resultset->bindValue(':id_produitf', $id_produitf);
            $_resultset->bindValue(':id_produith', $id_produith);
            $_resultset->bindValue(':prix_unitaire', $prixU);
            $_resultset->bindValue(':qte_produit', $qte_produit);
            $_resultset->bindValue(':prixtotal_produit', $prixTotal);
            $_resultset->bindValue(':allTotal', $allTotal);
            $_resultset->execute();
            $this->_db->commit();

        } catch (PDOException $e) {
            print "Echec " . $e->getMessage();
        }
    }

    function sommePrixTotalProduct()
    {
        $query = "select sum(prixtotal_produit) from panier";
        $_resultset = $this->_db->prepare($query);
        $_resultset->execute();
        $data = $_resultset->fetch();
        return $data[0];

    }
}
