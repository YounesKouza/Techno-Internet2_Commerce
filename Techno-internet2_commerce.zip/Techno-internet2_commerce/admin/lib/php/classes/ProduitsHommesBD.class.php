<?php

class ProduitsHommesBD extends ProduitsHommes
{
    private $_db;
    private $_array = array();

    function __construct($cnx)
    {
        $this->_db = $cnx;
    }

    function isProduitHommeInBD($nom_produitH, $num)
    {
        try {
            $query = "Select * from produitshommes where nom_produith=:nom_produith";
            $_resultset = $this->_db->prepare($query);
            $_resultset->bindValue(':nom_produith', $nom_produitH);
            $_resultset->execute();
            $_data = $_resultset->fetch();
            if (!empty($_data)) {
                if ($num == 2) {
                    return $_data;
                } else {
                    $_array[] = new ProduitsHommes($_data);
                    return $_array;
                }

            }
            return null;
        } catch (PDOException $e) {
            print "Echec " . $e->getMessage();
        }
    }

    function updateProduitsHommes($nom_produith, $id_produith, $nouveau)
    {
        try {
            $query = "update produitshommes set " . $nom_produith . "= '". $nouveau . "' where id_produith ='" . $id_produith . "'";
            $resultset = $this->_db->prepare($query);
            $resultset->execute();
            //print "query : ".$query;//s'affiche dans la console
            return "Success";
        } catch (PDOException $e) {
            print "Echec " . $e->getMessage();
        }
    }

    function getAllProduitsHommes()
    {
        try {
            $query = "select * from produitshommes order by id_produith";
            $_resultset = $this->_db->prepare($query);
            $_resultset->execute();

            while ($data = $_resultset->fetch()) {
                $_array[] = new ProduitsHommes($data);
            }
            if (!empty($_array)) {
                return $_array;
            } else {
                return null;
            }
        } catch (PDOException $e) {
            print "Erreur : " . $e->getMessage();
        }
    }

}
