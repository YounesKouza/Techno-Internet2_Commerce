<?php

class ProduitsFemmesBD extends ProduitsFemmes {
    private $_db;
    private $_array = array();

    function __construct($cnx) {
        $this->_db = $cnx;
    }

    function isProduitFemmeInBD($nom_produitF,$num){
        try{
            $query="Select * from produitsfemmes where nom_produitf=:nom_produitf";
            $_resultset = $this->_db->prepare($query);
            $_resultset->bindValue(':nom_produitf' , $nom_produitF);
            $_resultset->execute();
            $_data = $_resultset->fetch();
            if(!empty($_data)){
                if($num == 2){
                    return $_data;
                }
                else{
                    $_array[] = new ProduitsFemmes($_data);
                    return $_array;
                }

            }
            return null;
        }catch(PDOException $e){
            print "Echec ".$e->getMessage();
        }
    }

    function updateProduitsFemmes($nom_produitf,$id_produitf,$nouveau){
        try{
            $query = "update produitsfemmes set " . $nom_produitf . " = '" . $nouveau . "' where id_produitf ='" . $id_produitf . "'";
            $resultset = $this->_db->prepare($query);
            $resultset->execute();
            //print "query : ".$query;//s'affiche dans la console
        }catch(PDOException $e){
            print "Echec ".$e->getMessage();
        }
    }

    function getAllProduitsFemmes(){
        try {
            $query = "select * from produitsfemmes order by id_produitf";
            $_resultset = $this->_db->prepare($query);
            $_resultset->execute();

            while($data = $_resultset->fetch()){
                $_array[] = new ProduitsFemmes($data);
            }
            if(!empty($_array)){
                return $_array;
            }
            else {
                return null;
            }
        }catch(PDOException $e){
            print "Erreur : ".$e->getMessage();
        }
    }

}
