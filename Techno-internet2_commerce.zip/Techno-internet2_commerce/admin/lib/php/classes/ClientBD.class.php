<?php

class ClientBD extends Client
{
    private $_db;
    private $_array = array();

    function __construct($cnx)
    {
        $this->_db = $cnx;
    }

    function ClientInBD($email, $num)
    {
        try {
            $query = "Select * from client where email=:email";
            $_resultset = $this->_db->prepare($query);
            $_resultset->bindValue(':email', $email);
            $_resultset->execute();
            $_data = $_resultset->fetch();
            if (!empty($_data)) {
                if ($num == 2) {
                    return $_data;
                } else {
                    $_array[] = new Client($_data);
                    return $_array;
                }

            }
            return null;
        } catch (PDOException $e) {
            print "Echec " . $e->getMessage();
        }
    }

    function updateClient($id_client, $nom_client, $prenom_client, $email, $adresse, $code_postal, $ville)
    {

        try {
            $query = "update client set nom_client = '" . $nom_client . "', prenom_client = '" . $prenom_client . "', email = '" . $email . "', adresse = '" . $adresse . "', code_postal = '" . $code_postal . "', ville = '" . $ville . "' where id_client ='" . $id_client . "'";
            $resultset = $this->_db->prepare($query);
            $resultset->execute();
        } catch (PDOException $e) {
            print "Echec " . $e->getMessage();
            echo "<br>Erreur de modification : <br/> <strong>Info: </strong>" . $resultset->errorInfo()[2];
        }
    }

    function getAllClients()
    {
        try {
            $query = "select * from client order by id_client";
            $_resultset = $this->_db->prepare($query);
            $_resultset->execute();

            while ($data = $_resultset->fetch()) {
                $_array[] = new Client($data);
            }
            if (!empty($_array)) {
                return $_array;
            } else {
                return null;
            }
        } catch (PDOException $e) {
            print "Erreur : " . $e->getMessage();
        }
    }

    function getClient($prenom_client, $password)
    {
        try {
            $query = "select * from client where prenom_client=:prenom_client and password=:password";
            $_resultset = $this->_db->prepare($query);
            $_resultset->bindValue(':prenom_client', $prenom_client);
            $_resultset->bindValue(':password', $password);
            $_resultset->execute();
            $retour = $_resultset->fetch();
            if (!empty($retour)) {
                $_array[] = new client($retour);
                return $_array;
            } else {
                return null;
            }

        } catch (PDOException $e) {
            print "Erreur : " . $e->getMessage();
        }
    }

    function ObtenirClient()
    {
        // On récupère les informations de l'utilisateur connecté
        try {
            $query = "SELECT * FROM client WHERE id_client = " . $_SESSION['id_client'];
            $DB = $this->_db->prepare($query);
            $DB->execute();
            $data = $DB->fetch();
            $client = new Client($data);
            return $client;

        } catch (PDOException $e) {
            print "Erreur : " . $e->getMessage();
        }
    }

    function MessageApresModification()
    {
        if (isset($_POST['modification'])) {
            echo "<div class='container login_form'>";

            echo "<h1>";
            echo "Modification faite avec succés!";
            echo "</h1>";

            echo "<p>";
            echo " Vous avez modifié vos données personnelles avec succés .";
            echo "</p>";

            echo "</div>";
        }
    }


    function Connexion()
    {
        if (isset($_POST['submit_client'])) {
            extract($_POST, EXTR_OVERWRITE);
            //print $prenom_client . "-" .$password;
            $adm = $this->getClient($prenom_client, $password);
            if ($adm != null) {
                print "<br>Bienvenue " . $adm[0]->prenom_client;
                $_SESSION['prenom_client'] = $adm[0]->prenom_client;
                $_SESSION['id_client'] = $adm[0]->id_client;
                unset($_SESSION['page']);
                print "<meta http-equiv=\"refresh\": Content=\"0;url=./admin/index_Admin.php?page=accueil.php\">";

            } else {
                print "<br>Vous n'êtes pas membre ? Cliquez sur le lien Inscription pour devenir membre ";
            }

        }
    }


    function addClient()
    {
        if (isset($_POST['submit_client'])) {
            if (isset($_POST['nom_client']) && isset($_POST['prenom_client']) &&
                isset($_POST['adresse']) && isset($_POST['code_postal']) &&
                isset($_POST['ville']) && isset($_POST['email']) &&
                isset($_POST['password'])) {

                extract($_POST, EXTR_OVERWRITE);
                /*
                $nom_client = $_POST['nom_client'];
                $prenom_client = $_POST['prenom_client'];
                $adresse = $_POST['adresse'];
                $code_postal = $_POST['code_postal'];
                $ville = $_POST['ville'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                */

                try {
                    $query = "INSERT INTO client(nom_client, prenom_client, email, adresse, code_postal, ville, password) 
            values('" . $nom_client . "', '" . $prenom_client . "', '" . $email . "', '" . $adresse . "', '" . $code_postal . "', '" . $ville . "'
                    ,'" . $password . "')";

                    $_resultset = $this->_db->prepare($query);
                    $_resultset->execute();
                    //$this->_db->commit();

                    echo "<div style='text-align: center;'>";
                    echo "Nouveau client inséré";
                    echo "<br>Votre login est <strong>" . $_POST['prenom_client'] . "</strong>";
                    echo "</div>";

                } catch (Exception $e) {
                    print "Erreur : " . $e->getMessage();
                    echo "<br>Erreur d'enregistrement : <br/> 1. <strong>Info: </strong>" . $_resultset->errorInfo()[2] . "<br/>2. <strong>Requête</strong>: " . $query;
                }

            } else {
                echo "Tous les champs sont requis.";
                die();
            }
        } else {
            echo "Le bouton Submit n'est pas défini";
        }
    }
}
