<nav id="myMenu" class="menuPrincip" xmlns="http://www.w3.org/1999/html">
    <div style="display: flex">
        <li class="menuPrincipAccueil">
            <a class="menuPrincipAccueil" aria-current="page" href="index_Admin.php?page=accueil.php" name="accueil">
                <img class="menuPrincipAccueil" src="./images/Logo_Palace.jpg" width="35px" height="25px">
            </a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_Admin.php?page=Gestion_Produits.php" name="gestion-des-produits">Gestion
                des produits</a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_Admin.php?page=VetementsHommes_js_explore.php" name="mode-homme">Mode
                homme</a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_Admin.php?page=VetementsFemmes_js_explore.php" name="mode-femme">Mode
                femme</a>
        </li>
    </div>

    <div style="margin-right: 10px; display: flex">
        <form>
            <input class="search-data" type="search" placeholder="Rechercher" id="search-item" onkeyup="search()"
                   required>
            <button class="fas fa-search"></button>
        </form>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_Admin.php?page=Panier.php" name="panier"><i
                        class="fa-solid fa-bag-shopping"></i></a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_Admin.php?page=Disconnect.php" name="déconnexion">Déconnexion</a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_Admin.php?page=DataClient.php">
                <p style="margin: 0;">Login: <?php echo $_SESSION['prenom_client']; ?> </p>
            </a>
        </li>
    </div>

</nav>