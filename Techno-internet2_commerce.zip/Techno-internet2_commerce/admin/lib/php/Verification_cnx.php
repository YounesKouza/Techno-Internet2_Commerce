<?php
if (!isset($_SESSION['prenom_client'])) {
    print "<meta http-equiv=\"refresh\": Content=\"0;url=../index_.php?page=Accueil.php\">";
    exit();
}