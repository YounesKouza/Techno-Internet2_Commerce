<?php
$dsn = 'pgsql:host=localhost; dbname=vetement; port=5432';
$user = 'Ugur';
$password = 'condorcet';