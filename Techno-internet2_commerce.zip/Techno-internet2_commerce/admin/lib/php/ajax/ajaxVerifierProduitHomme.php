<?php
header('Content-Type: application/json');
require '../pgConnect.php';
require '../classes/Connexion.class.php';
require '../classes/ProduitsHommes.class.php';
require '../classes/ProduitsHommesBD.class.php';
$cnx = Connexion::getInstance($dsn,$user,$password);

try{
    $prodH = array();
    $produitH = new ProduitsHommesBD($cnx);
    //Appel d'une fonction définie dans ProduitsHommesBD
    $pr[] = $produitH->isProduitHommeInBD($_GET['nom_produith'],2);

    //conversion du tableau PHP au format json (syntaxe javascript)
    print json_encode($pr);

}catch(PDOException $e){
    print "Echec";
}