<?php
header('Content-Type: application/json');
require '../pgConnect.php';
require '../classes/Connexion.class.php';
require '../classes/ProduitsFemmes.class.php';
require '../classes/ProduitsFemmesBD.class.php';
$cnx = Connexion::getInstance($dsn,$user,$password);

try{
    $prodF = array();
    $produitF = new ProduitsFemmesBD($cnx);
    //Appel d'une fonction définie dans ProduitsFemmesBD
    $pr[] = $produitF->isProduitFemmeInBD($_GET['nom_produitf'],2);

    //conversion du tableau PHP au format json (syntaxe javascript)
    print json_encode($pr);

}catch(PDOException $e){
    print "Echec";
}