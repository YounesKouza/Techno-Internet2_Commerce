<?php
header('Content-Type: application/json');
require '../pgConnect.php';
require '../classes/Connexion.class.php';
require '../classes/ProduitsFemmes.class.php';
require '../classes/ProduitsFemmesBD.class.php';
$cnx = Connexion::getInstance($dsn, $user, $password);

try {
    $update = new ProduitsFemmesBD($cnx);

    extract($_GET, EXTR_OVERWRITE);
    //$parametre = 'id_produitf='.$id_produitf.'&nom_produitf='.$nom_produitf.'&nouveau='.$nouveau;
    $update->updateProduitsFemmes($champ, $id, $nouveau);

    print json_encode($update);

} catch (PDOException $e) {
    print $e->getMessage() . " " . $e->getLine() . " " . $e->getTrace() . " " . $e->getCode();
}
