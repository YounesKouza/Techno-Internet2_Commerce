<?php
header('Content-Type: application/json');
require '../pgConnect.php';
require '../classes/Connexion.class.php';
require '../classes/Client.class.php';
require '../classes/ClientBD.class.php';
$cnx = Connexion::getInstance($dsn, $user, $password);

try {
    $update = new ClientBD($cnx);

    extract($_GET, EXTR_OVERWRITE);
    $update->updateClient($id_client, $nom_client, $prenom_client, $email, $adresse, $code_postal, $ville);
    //header("Refresh:0");
    print json_encode($update);
    return "Sucesss";

} catch (PDOException $e) {
    print $e->getMessage() . " " . $e->getLine() . " " . $e->getTrace() . " " . $e->getCode();
}
