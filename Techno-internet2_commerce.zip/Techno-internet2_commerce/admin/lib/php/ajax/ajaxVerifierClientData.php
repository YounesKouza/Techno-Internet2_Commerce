<?php
header('Content-Type: application/json');
require '../pgConnect.php';
require '../classes/Connexion.class.php';
require '../classes/Client.class.php';
require '../classes/ClientBD.class.php';
$cnx = Connexion::getInstance($dsn,$user,$password);

try{
    $cli = array();
    $client = new ClientBD($cnx);

    $C[] = $client->ClientInBD($_GET['email'],2);

    //conversion du tableau PHP au format json (syntaxe javascript)
    print json_encode($C);

}catch(PDOException $e){
    print "Echec";
}