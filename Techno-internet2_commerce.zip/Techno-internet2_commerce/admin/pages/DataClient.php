<?php
include './lib/php/Verification_cnx.php';

$cli = new ClientBD($cnx);
$client = $cli->ObtenirClient();

?>

<?php
$cli2 = new ClientBD($cnx);
$client2 = $cli2->MessageApresModification();
?>
        <h3 class="titreProduits">Modifier Vos données</h3>
        <div class="container login_form">
            <form method="post" onsubmit="myFunction()" action="">
                <div class="mb-3">
                    <label for="nom_client" class="form-label">Nom : </label>
                    <input name="nom_client" id="nom_client" type="text" class="form-control"
                           value="<?php print $client->nom_client; ?>">
                </div>
                <div class="mb-3">
                    <label for="prenom_client" class="form-label">Prénom : </label>
                    <input name="prenom_client" id="prenom_client" type="text" class="form-control"
                           value="<?php print $client->prenom_client; ?>">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">E-mail : </label>
                    <input name="email" id="email" type="email" class="form-control"
                           value="<?php print $client->email; ?>">
                </div>
                <div class="mb-3">
                    <label for="adresse" class="form-label">Adresse : </label>
                    <input name="adresse" id="adresse" type="text" class="form-control"
                           value="<?php print $client->adresse; ?>"
                </div>
                <div class="mb-3">
                    <label for="code_postal" class="form-label">Code postal : </label>
                    <input name="code_postal" id="code_postal" type="text" class="form-control"
                           value="<?php print $client->code_postal; ?>">
                </div>
                <div class="mb-3">
                    <label for="ville" class="form-label">Ville : </label>
                    <input name="ville" id="ville" type="text" class="form-control"
                           value="<?php print $client->ville; ?>">
                </div>
                <button id="submit_client" value="<?php print $client->id_client; ?>" name="modification"
                        class="btn btn-outline-primary" type="submit">Modifier
                </button>
            </form>
        </div>

<script>
    function myFunction() {
        alert("Modification faite avec succés! Vous avez modifié vos données personnelles avec succés.");
    }
</script>