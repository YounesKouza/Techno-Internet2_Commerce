<?php
include './lib/php/Verification_cnx.php';
//var_dump($_GET);
$panier = new PanierBD($cnx);
$paniers = $panier->getAllPaniers();
$nbr_vet = count($paniers);
//var_dump($paniers);

?>

<div class="titrePanier">Panier</div>
<table class="table table-striped" style="text-align: center;">
    <thead>
    <tr>
        <th scope="col" class="titreCol">Id produit</th>
        <th scope="col" class="titreCol">Nom produit</th>
        <th scope="col" class="titreCol">Prix unitaire</th>
        <th scope="col" class="titreCol">Quantités</th>
        <th scope="col" class="titreCol">Prix total par produit</th>
    </tr>
    </thead>
    <tbody class="colonne">
    <?php
    for ($i = 0; $i < $nbr_vet; $i++) {
        ?>
        <tr id="myTR">
            <td><?php
                if ($paniers[$i]->id_produith) {
                    print "<p>ID PH : " . $paniers[$i]->id_produith . "</p>"; ?>
                    <?php
                } else {
                    print "<p>ID PF : " . $paniers[$i]->id_produitf . "</p>"; ?>
                    <?php
                } ?>
            </td>
            <td><?php
                if ($paniers[$i]->nom_produith) {
                    print "<p>" . $paniers[$i]->nom_produith . "</p>"; ?>
                    <?php
                } else {
                    print "<p>" . $paniers[$i]->nom_produitf . "</p>"; ?>
                    <?php
                } ?>
            </td>

            <td><?php print $paniers[$i]->prix_unitaire; ?> €</td>
            <td><?php print $paniers[$i]->qte_produit; ?> </td>
            <td><?php print $paniers[$i]->prixtotal_produit; ?> €</td>

        </tr>
        <?php
    }
    ?>
    </tbody>

</table>

<table class="table table-striped">
    <?php
    $panier2 = new PanierBD($cnx);
    $allTotal = $panier2->sommePrixTotalProduct();
    ?>
    <th scope="col" class="total"><?php print "prix total: " . $allTotal; ?>€</th>
</table>
