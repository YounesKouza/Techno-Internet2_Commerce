<?php
include './lib/php/Verification_cnx.php';

$produitsH = new ProduitsHommesBD($cnx);
$prodH = $produitsH->getAllProduitsHommes();
$nbr_prodH = count($prodH);

$produitsF = new ProduitsFemmesBD($cnx);
$prodF = $produitsF->getAllProduitsFemmes();
$nbr_prodF = count($prodF);

//var_dump($prodH);
//var_dump($prodF);

?>

<div class="container">
    <table class="table" style="text-align: center; border-color: blue;">

        <tr>
            <th scope="col" style="background-color: black;"></th>
            <th scope="col" style="background-color: lightskyblue;"></th>
            <th scope="col" style="background-color: black;"></th>
            <th scope="col" style="background-color: lightskyblue;"></th>
        </tr>

        <div class="titreProduits">Produits Hommes</div>
        <tbody>
        <?php
        for ($i = 0; $i < $nbr_prodH; $i++) {
            ?>
            <tr>
                <td><?php print $prodH[$i]->id_produith; ?></td>
                <td>
                    <span contenteditable="true" name="nom_produith" class="ecart"
                          id="<?php print $prodH[$i]->id_produith; ?>">
                        <?php print $prodH[$i]->nom_produith; ?>
                    </span>
                </td>
                <td>
                    <span contenteditable="true" name="prix_unitaire" class="ecart"
                          id="<?php print $prodH[$i]->id_produith; ?>">
                        <?php print $prodH[$i]->prixunitaire_produith; ?> €
                    </span>
                </td>
                <td>
                    <span contenteditable="false" name="imageHomme" class="ecart"
                          id="<?php print $prodH[$i]->id_produith; ?>">
                        <img src="./imagesHommes/<?php print $prodH[$i]->image_produith; ?>"
                             style="height: 200px; width: 150px;"/>
                    </span>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
</div>

<div class="container">
    <table class="table" style="text-align: center; border-color: red;">

        <tr>
            <th scope="col" style="background-color: lightskyblue;"></th>
            <th scope="col" style="background-color: black;"></th>
            <th scope="col" style="background-color: lightskyblue;"></th>
            <th scope="col" style="background-color: black;"></th>
        </tr>

        <div class="titreProduits">Produits Femmes</div>
        <tbody>
        <?php
        for ($i = 0; $i < $nbr_prodF; $i++) {
            ?>
            <tr>
                <td><?php print $prodF[$i]->id_produitf; ?></td>
                <td>
                    <span contenteditable="true" name="nom_produitf" class="ecart"
                          id="<?php print $prodF[$i]->id_produitf; ?>">
                        <?php print $prodF[$i]->nom_produitf; ?>
                    </span>
                </td>
                <td>
                    <span contenteditable="true" name="prix_unitaire" class="ecart"
                          id="<?php print $prodF[$i]->id_produitf; ?>">
                        <?php print $prodF[$i]->prixunitaire_produitf; ?> €
                    </span>
                </td>
                <td>
                    <span contenteditable="false" name="imageFemme" class="ecart"
                          id="<?php print $prodF[$i]->id_produitf; ?>">
                        <img src="./imagesFemmes/<?php print $prodF[$i]->image_produitf; ?>"
                             style="height: 200px; width: 150px;"/>
                    </span>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
</div>