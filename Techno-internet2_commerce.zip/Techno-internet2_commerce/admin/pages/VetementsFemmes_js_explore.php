<?php
include './lib/php/Verification_cnx.php';
//var_dump($_GET);
$categ = new ProduitsFemmesBD($cnx);
$produits = $categ->getAllProduitsFemmes();
$nbr_vetF = count($produits);
//var_dump($produits);
?>

<div class="titreProduits">Produits Femmes</div>

<script src="../js/Recherche.js"></script>
<div class="rechercheProduits">
    <form class="search-container">
        <input class="search-data" type="search" placeholder="Rechercher" id="search_Vetement" onkeyup="searchVet()"
               required>
        <button class="fas fa-search" type="submit"></button>
    </form>
</div>

<div class="produits" id="prod">
    <div class="container">
        <div class="row row-cols-md-3 g-3">
            <?php
            for ($i = 0; $i < $nbr_vetF; $i++) {
                ?>
                <div>
                    <div class="card shadow-sm">
                        <svg class="bd-placeholder-img card-img-top" width="100%" height="250"
                             xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice"
                             focusable="false">

                            <img src="./imagesFemmes/<?php print $produits[$i]->image_produitf; ?>"
                                 style="margin-top: -250px;"/>

                        </svg>

                        <div class="card-body">
                            <p class="card-text_produits">
                                <?php print $produits[$i]->nom_produitf; ?>
                            </p>
                            <p class="card-text_produits">
                                <?php print $produits[$i]->prixunitaire_produitf; ?> €
                            </p>

                            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                                <input type="hidden" name="id_produith"
                                       value="<?php print $produits[$i]->id_produith; ?>">
                                <input type="hidden" name="prix_unitaire"
                                       value="<?php print $produits[$i]->prixunitaire_produith; ?>">

                                <!--
                                <input type="number" class="input-number" name="qte" min="1" max="200" step="1" required
                                       style="height: 25px; width: 100px;">
                                -->
                                <div class="number-input">
                                    <span onclick="this.parentNode.querySelector('input[type=number]').stepDown()"></span>
                                    <input class="quantity" min="1" name="qte" value="1" type="number">
                                    <span onclick="this.parentNode.querySelector('input[type=number]').stepUp()"
                                          class="plus">
                                    </span>

                                    <button type="submit" class="btn btn-success" name="ajout">
                                        Ajout <i class="fa fa-shopping-bag"></i>
                                    </button>

                                </div>

                            </form>

                        </div>

                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>

<?php
if (isset($_POST['ajout'])) {
    //extract($_POST, EXTR_OVERWRITE);
    $panier = new PanierBD($cnx);
    echo "Ici id_client : " . $_SESSION['id_client'];
    $panier->addProduct(null, $_POST['id_produitf'], $_SESSION['id_client'], $_POST['qte'], $_POST['prix_unitaire'], $_GET['prixtotal_produit']);
}
?>

