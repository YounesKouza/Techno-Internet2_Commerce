<?php
session_destroy();
print "<meta http-equiv=\"refresh\": Content=\"0;URL=../index_.php\">"

?>
