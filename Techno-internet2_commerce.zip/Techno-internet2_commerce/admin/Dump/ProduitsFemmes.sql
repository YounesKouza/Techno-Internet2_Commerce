INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (1, 'Jean Mom taille haute Blanc', 40.00, 'Jeans1_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (2, 'Jean Mom élastique Noir', 30.00, 'Jeans2_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (3, 'Jean Mom taille haute Bleu moyen', 40.00, 'Jeans3_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (4, 'Jean straight color bloc Bleu moyen', 40.00, 'Jeans4_Femmes.webp', 1);

INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (5, 'Pantalon de costume en lin Bleu ciel', 40.00, 'Pantalon1_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (6, 'Pantalon droit costume Écru', 40.00, 'Pantalon2_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (7, 'Pantalon lin ceinture Rouge', 50.00, 'Pantalon3_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (8, 'Pantalon lin ceinture Noir', 50.00, 'Pantalon4_Femmes.webp', 1);

INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (9, 'Sweat-shirt manches bouffantes Rose pastel', 20.00, 'Pull1_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (10, 'Sweat-shirt manches bouffantes Sable', 20.00, 'Pull2_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (11, 'Sweat-shirt texturé tresses Écru', 20.00, 'Pull3_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (12, 'Sweat-shirt coton Mickey Mouse Blanc', 40.00, 'Pull4_Femmes.webp', 1);

INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (13, 'T-shirt premium oversize coton Vert', 15.00, 'T-Shirt1_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (14, 'T-shirt premium oversize coton Blanc', 15.00, 'T-Shirt2_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (15, 'T-shirt détails ajourés Noir', 15.00, 'T-Shirt3_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (16, 'T-shirt coutures décoratives Vert d''eau', 30.00, 'T-Shirt4_Femmes.webp', 1);

INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (17, 'Veste de costume lin Bleu ciel', 60.00, 'Veste1_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (18, 'Veste de costume lin Blanc', 60.00, 'Veste2_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (19, 'Veste de costume lin Rouge', 70.00, 'Veste3_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (20, 'Veste lin oversize Noir', 70.00, 'Veste4_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (21, 'Veste bomber oversize Noir', 100.00, 'Veste5_Femmes.webp', 1);
INSERT INTO public.produitsfemmes (id_produitf, nom_produitf, prixunitaire_produitf, image_produitf, id_categorie)
VALUES (22, 'Blouson biker similicuir Noir', 50.00, 'Veste6_Femmes.webp', 1);