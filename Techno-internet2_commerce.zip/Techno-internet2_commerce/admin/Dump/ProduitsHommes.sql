INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (1, 'Jean Tom tapered-fit Lyocell Bleu moyen', 50.00, 'Jeans1_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (2, 'Jean Tom tapered-fit Lyocell Noir', 50.00, 'Jeans2_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (3, 'Jean Tom tapered-fit Lyocell Bleu foncé', 50.00, 'Jeans3_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (4, 'Jean Ben tapered-fit Bleu clair', 50.00, 'Jeans4_Hommes.webp', 1);

INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (5, 'Pantalon lin slim-fit Écru', 50.00, 'Pantalon1_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (6, 'Pantalon lin slim-fit Bleu marine foncé', 50.00, 'Pantalon2_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (7, 'Pantalon de costume slim fit lin Gris chiné clair', 70.00, 'Pantalon3_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (8, 'Pantalon coton tapered crop Noir', 40.00, 'Pantalon4_Hommes.webp', 1);

INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (9, 'Sweat-shirt basique coton Sable', 30.00, 'Pull1_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (10, 'Sweat-shirt basique coton Bleu marine foncé', 30.00, 'Pull2_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (11, 'Sweat-shirt imprimé Vert foncé', 50.00, 'Pull3_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (12, 'Sweat-shirt coton imprimé Blanc', 50.00, 'Pull4_Hommes.webp', 1);

INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (13, 'Sweater coton manches courtes Gris glacé', 40.00, 'T-Shirt1_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (14, 'Sweater coton manches courtes Noir', 40.00, 'T-Shirt2_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (15, 'T-shirt regular-fit mercerisé Noir', 20.00, 'T-Shirt3_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (16, 'T-shirt coton relaxed-fit Vert', 20.00, 'T-Shirt4_Hommes.webp', 1);

INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (17, 'Veste coton lin à fermeture éclair Bleu marine foncé', 80.00, 'Veste1_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (18, 'Veste denim poches Bleu ciel', 50.00, 'Veste2_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (19, 'Blouson biker double face Noir', 120.00, 'Veste3_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (20, 'Veste double face Marron moyen', 120.00, 'Veste4_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (21, 'Anorak court thermorégulateur Vert', 80.00, 'Veste5_Hommes.webp', 1);
INSERT INTO public.produitshommes (id_produith, nom_produith, prixunitaire_produith, image_produith, id_categorie)
VALUES (22, 'Anorak court thermorégulateur Bleu marine foncé', 80.00, 'Veste6_Hommes.webp', 1);