<nav id="myMenu" class="menuPrincip" xmlns="http://www.w3.org/1999/html">

    <div style="display: flex">
        <li class="menuPrincipAccueil">
            <a class="menuPrincipAccueil" href="index_.php?page=Accueil.php" name="accueil">
                <img class="menuPrincipAccueil" src="./admin/images/Logo_Palace.jpg" width="35px" height="25px">
            </a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_.php?page=VetementsHommes_js_explore.php" name="mode-homme">Mode homme</a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_.php?page=VetementsFemmes_js_explore.php" name="mode-femme">Mode femme</a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_.php?page=Qui_js_explore.php" name="aide-qui-sommes-nous">Qui sommes-nous?</a>
        </li>
    </div>
    <div style="margin-right: 10px; display: flex">
        <form>
            <input  class="search-data" type="search" placeholder="Rechercher" id="search-item" onkeyup="search()" required>
            <button class="fas fa-search"></button>
        </form>
        <li class ="menuPrincip">
            <a class="menuPrincip" href="index_.php?page=Panier.php" name="panier"><i class="fa-solid fa-bag-shopping"></i></a>
        </li>
        <li class="menuPrincip">
            <a class="menuPrincip" href="index_.php?page=login.php" name="compte-user-connexion"><i class="fa-solid fa-user"></i></a>
        </li>

    </div>


</nav>